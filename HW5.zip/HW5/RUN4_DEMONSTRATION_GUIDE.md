# Chapter 4 Replication Demonstration Guide

## Overview
The enhanced `run4()` function in `test.erl` now comprehensively demonstrates all replication features of your DHT implementation with `node4.erl`.

## What Has Been Added

### Enhanced Logging in node4.erl
1. **`print_storage` message handler** - Shows both Storage AND Replica for each node
2. **Add operation logging** - Shows when keys are stored locally and replicated to successor
3. **Replicate operation logging** - Shows when a node receives a replica
4. **Down handler logging** - Shows when predecessor/successor dies and recovery actions

### New run4() Test Structure

The test is divided into 4 demonstrations:

---

## DEMONSTRATION 1: Replication on Add
**Goal**: Prove that any addition to the DHT is replicated

**What happens**:
1. Creates a 3-node ring (n1, n2, n3)
2. Adds 3 individual keys with delays between each
3. Prints storage and replicas for all nodes

**Watch for**:
- `[Node X] STORING key Y locally (responsible), REPLICATING to successor`
- `[Node Z] RECEIVED REPLICA of key Y`
- Each node's print_storage showing both storage and replica keys

**Proves**: Every key added is both stored on the responsible node AND replicated to its successor

---

## DEMONSTRATION 2: Keys Recoverable After Node Death
**Goal**: If I kill a node, its keys can still be looked up (they were replicated)

**What happens**:
1. Adds 3 keys to the ring
2. Runs lookup check - all keys found
3. **Kills node N2**
4. Waits for recovery
5. Runs lookup check again - all keys STILL found

**Watch for**:
- Before kill: `check(1, TestKeys, n1)` - all succeed
- After kill: `check(2, TestKeys, n1)` - all STILL succeed
- The lookup operations show keys being found from different nodes

**Proves**: Keys stored on a dead node remain accessible because they were replicated to successor

---

## DEMONSTRATION 3: Re-replication After Recovery
**Goal**: When recovering keys from a dead node, the node that is now responsible re-replicates them

**What happens**:
1. After N2 dies, nodes merge replicas into storage
2. Adds 2 MORE keys to the ring
3. Prints storage and replicas
4. Verifies all 5 keys are still retrievable

**Watch for**:
- `[Node X] PREDECESSOR DIED - Merging replica into storage and re-replicating to successor`
- `Storage before merge: A, Replica size: B, After merge: C`
- The new keys being replicated
- All 5 keys passing lookup checks

**Proves**: 
- Recovered keys from dead predecessor are merged into storage
- The node re-replicates ALL its keys (including recovered ones) to its successor
- At least 2 copies of every key exist at all times

---

## DEMONSTRATION 4: Specific A-B-C Scenario
**Goal**: Nodes A and B (A < B) store keys P and Q, replicate each other. Node C joins as B's successor. B dies. Result: A stores P+replicates Q, C stores Q+replicates P. No data lost.

**What happens**:
1. Starts node A (n4)
2. Starts node B (n5) joining A
3. Adds key P and key Q
4. Prints A and B state (each has storage + replica)
5. **Node C (n6) joins** as successor
6. Waits for stabilization and handover
7. Prints A, B, C state (keys distributed)
8. **Kills node B (n5)**
9. Waits for recovery
10. Prints final A and C state
11. Verifies both P and Q are still retrievable

**Watch for**:
- Initial state: A and B have both P and Q distributed
- After C joins: Keys redistributed via handover
- After B dies:
  - `[Node X] PREDECESSOR DIED` or `[Node Y] SUCCESSOR DIED`
  - Replica merging messages
  - Re-replication to new successors
- Final state: Both P and Q found in final check

**Proves**:
- The specific scenario you described works correctly
- No data is lost even when the middle node dies
- Keys are properly redistributed and re-replicated
- The system maintains at least 2 copies of each key

---

## How to Run

### Option 1: Run the full test
```erlang
erl
c(key).
c(storage).
c(node4).
c(test).
test:run4().
```

### Option 2: Run just specific demonstrations
You can modify `run4()` to comment out demonstrations you don't want to see.

---

## Expected Output Pattern

```
========================================
CHAPTER 4: REPLICATION DEMONSTRATION
========================================

--- Setting up initial 3-node ring ---

=== DEMONSTRATION 1: Replication on Add ===
Adding 3 keys - watch for STORING and REPLICATING messages

[Node 123456] STORING key 789012 locally (responsible), REPLICATING to successor
[Node 234567] RECEIVED REPLICA of key 789012
...

[Node 123456] Storage: size=2, keys=[...]
[Node 123456] Replica: size=1, keys=[...]
...

=== DEMONSTRATION 2: Keys Recoverable After Node Death ===
Killing node N2 - its keys should still be retrievable from replicas

Before killing N2, all keys should be found:
{op: look, count: 1, id: 3, time: X.XXms, failed: 0, timeout: 0}

Killing N2...

[Node X] PREDECESSOR DIED - Merging replica into storage...

After killing N2, all keys STILL be found (from replicas):
{op: look, count: 2, id: 3, time: X.XXms, failed: 0, timeout: 0}
...

=== DEMONSTRATION 3: Re-replication After Recovery ===
...

=== DEMONSTRATION 4: Specific A-B-C Scenario ===
...

========================================
CHAPTER 4 TESTS COMPLETE
========================================

SUMMARY:
1. ✓ Demonstrated that additions are replicated to successor
2. ✓ Demonstrated that keys are recoverable after node death (from replicas)
3. ✓ Demonstrated re-replication after recovering from dead node
4. ✓ Demonstrated A-B-C scenario with no data loss
```

---

## Key Metrics to Watch

1. **Replication confirmation**: Every add should produce a replica message
2. **Zero failed lookups**: All `check()` calls should report `failed: 0`
3. **Storage + Replica sizes**: Before death vs after merge should add up correctly
4. **No data loss**: Final checks should find all keys added throughout the test

---

## Troubleshooting

If lookups fail:
- Increase sleep timers (ring may need more stabilization time)
- Check that all nodes compiled successfully
- Verify monitors and down handlers are working (check for DOWN messages)

If replicas not showing:
- Check that the `{replicate, ...}` handler is being called
- Verify successor chain is correct (use probe messages)
- Ensure storage:add is being called in replica handler

---

## Files Modified

1. **node4.erl**:
   - Added `print_storage` handler (shows storage AND replica)
   - Added logging to `add/8` (shows storing + replicating)
   - Added logging to `{replicate, ...}` handler (shows replica received)
   - Enhanced `down/6` with detailed logging

2. **test.erl**:
   - Completely rewrote `run4()` with 4 focused demonstrations
   - Added detailed progress messages
   - Added summary output
   - Used smaller key sets for clarity

---

## Next Steps

After running `test:run4()`, you can:
1. Review the console output for all 4 demonstrations
2. Copy relevant output sections for your report
3. Take screenshots showing:
   - Replication messages during adds
   - Storage/Replica states before and after node deaths
   - Zero failed lookups after recovery
   - Final state of A-B-C scenario
