#!/bin/bash

# Get current working directory
CURRENT_DIR=$(pwd)

# Open a new Terminal window and start Erlang node in current directory
osascript -e "tell application \"Terminal\" to do script \"cd $CURRENT_DIR; erl -name sweden -setcookie 1234 -connect_all false -eval 'compile:file(\\\"routy\\\"), compile:file(\\\"intf\\\"), compile:file(\\\"map\\\"), compile:file(\\\"hist\\\"),compile:file(\\\"routy_demo\\\"),compile:file(\\\"dijkstra_debug\\\"), compile:file(\\\"dijkstra\\\").'\""


