-module(routy_demo).
-export([bench/0]).
-define(ITALY,'italy@130.229.168.103').
-define(SPAIN,'spain@130.229.168.103').

bench()->
    %Start the routers 
    routy:start(r1,stockholm),
    routy:start(r2,lund),
    routy:start(r3,lulea),
    routy:start(r4,orebro),
    routy:start(r5,goteborg),

    %Build the connections
    r1 ! {add,lund,whereis(r2)},
    r2 ! {add,stockholm,whereis(r1)},
    r1 ! {add,lulea,whereis(r3)},
    r3 ! {add,stockholm,whereis(r1)},
    r2 ! {add,orebro,whereis(r4)},
    r4 ! {add,lund,whereis(r2)},
    r4 ! {add,goteborg,whereis(r5)},
    r5 ! {add,orebro,whereis(r4)},

    

    io:format("Sleeping for routers to initialize"),
    timer:sleep(3000),

    io:format("Routers started and connected.~n"),

    %Broadcasting messages
    routy:broadcast(r1),
    timer:sleep(100),
    routy:broadcast(r2),
    timer:sleep(100),
    routy:broadcast(r3),
    timer:sleep(100),
    routy:broadcast(r4),
    timer:sleep(100),
    routy:broadcast(r5),

    timer:sleep(2000),
    
    %Updating routing tables
    routy:update(r1),
    timer:sleep(100),
    routy:update(r2),
    timer:sleep(100),
    routy:update(r3),
    timer:sleep(100),
    routy:update(r4),
    timer:sleep(100),
    routy:update(r5),

    timer:sleep(2000),

    %print status
    routy:status(r1),
    routy:status(r2),
    routy:status(r3),
    routy:status(r4),
    routy:status(r5),

    timer:sleep(2000),
    %send a message
    r1 ! {route, goteborg, r1, "Hello from Stockholm to Goteborg!"},

    %timer:sleep(500),
    %Send a second message
    %r3 ! {route,goteborg,r1,"Hello bro"},

    %timer:sleep(500),
    r1 ! {remove,lund},
    timer:sleep(200),
    routy:update(r1),
    routy:update(r3),
    routy:update(r4),
    routy:update(r5),

    io:format("~n Separation line ~n"),

    timer:sleep(500),
    routy:status(r1),


    io:format("~n Separation line ~n"),
    r1 ! {route, goteborg, r1, "Hello from Stockholm to Goteborg!"},


    ok.
