# Project title
Rudy server

## Description of the files
-rudy.erl is the initial server
-test.erl contains the test bench
-rudy_pool.erl contains the updated code for the optional task
-graph.py is a script to draw the graph for the case of multithreading
-graph.nomulti.py is a script to draw the graph for the case of the rudimental server
-Result1.csv and Result2.csv contain the parsingTime for each request in the case of multithreading
-ResultSingolar1.csv and ResultSingolar2.csv contain the parsingTime for each request in the case of the rusimental server
-HW1_Rudy.pdf is the report